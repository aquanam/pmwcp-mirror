# First news!
### Author
Ruben Preece
### Created at
Sun May 26
### -----------------------------------

Hello everyone! This is the first news item, mainly because of testing. If you did `pfnews read`, when you do it again, you wouldn't see this anymore becuase you have read this. Don't worry, though. You can always do `pfnews read --name="first_news"`!